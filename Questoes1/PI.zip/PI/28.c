#include <stdio.h>

void insere (int v[], int N, int x) {
  int i;
  int w[1024];
  for(i = 0; i < N; i++){
    if(x <= v[i]){ 
      w[i] = x;
      w[i + 1] = v[i];
    }
    else w[i] = v[i];
  }
  for(i = 0;i < N + 1; i++){ 
    printf("%d ",w[i]);
  }
}

int main (){
  int v[]={1,2,3,4,5,7};
  int N=6;
  int x=6;
  insere (v,N,x);
  return 0;
}

      
