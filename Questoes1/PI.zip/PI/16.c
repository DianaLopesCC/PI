# include <stdio.h>

char maisfreq (char s []) {
  int freq = 1;
  int max = 1;
  int i;
  char res='0';
  for (i=0; s[i] != '\0'; i++) {
    if (s[i] == s[i+1]) {
      freq++;
      if (max < freq) {
	max = freq;
	res = s[i];
      }
    }
  }
  return res;
}

int main () {
  char x;
  char s[] = "aaabbbcccc";
  x = maisfreq (s);
  printf("A letra mais vrequente é %c\n", x);
}
