#include <stdio.h>

int bitsUm (unsigned int n){
	int c=0;
	while(n / 10.0 > 0){
		if (n % 10 == 1){
			c++;
		}
		n=n/10;
	}
	printf("O numero de bist é %d\n",c);
	return c;
}

int main (){
	int tot;
	bitsUm(110100);
}