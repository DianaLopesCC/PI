#include <stdio.h>

int comunsOrd (int a[], int na, int b[], int nb){
  int i,j,n=0;
  for (i=0 ; i< na ; i++){
    for (j=0 ; j< nb ; j++){
      if (a[i]==b[j]) n++;
    }
  }
  return n;
}

int main () {
  int a[]={1,2,3,4};
  int na=4;
  int b[]={1,2,4,5,6,7,8};
  int nb=7;
  int r;
  r=comunsOrd (a,na,b,nb);
  printf ("%d",r);
  return r;
}
