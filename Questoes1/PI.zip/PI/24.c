# include <stdio.h>
# include <string.h>

int pertence (int n,char c[]){
  int i;
  for(i=0;c[i]!='\0';i++){
    if (n==c[i]) return 0;
  }
  return 1;
}

int contida (char a[], char b[]){
  int i,j=0;
  for (i=0;a[i]!='\0';i++) {
    if (pertence(a[i],b)==1)
      return 1;
  }
  return 0;
}

int main (){
  char a[]="braga";
  char b[]="bracarence";
  int x;
  x=contida(a,b);
  printf("%d",x);
  return 0;
}
