# include <stdio.h>

int strlenn (char str []){
	int n=0;
	int i=0;
	while (str[i] != '\0'){
		n++;
		i++;
	}
	printf("Numero %d\n",n);
	return n;
}

int main (){
	int total;
	char a[]="DIANA";
	total=strlenn(a);
}