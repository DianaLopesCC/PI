# include <stdio.h>
# include <string.h>

int contaPal (char s[]){
	int i,total=0;
	for (i=0;s[i]!='\0';i++){
		if (s[i]==' '){
			total++;
		}
	}
	total=total+1; // a que esta em ultimo que tem o '\0' a terminar
	printf("Temos %d\n palavras", total);
	return total;
}

int main (){
	char s[]="a bds aljdfkjh s";
	contaPal(s);
}