# include <stdio.h>

int crescente (int a[], int i, int j){
	int r=0;
	for(;(i+1)<=j;i++){
		if (a[i]>a[i+1]){
			r=1;		}
	}
	printf("%d\n", r);
	return r;
}

int main (){
	int a[]={2,3,1,4,5,3,6,4};
	crescente(a,2,5);
}