#include <stdio.h>
#include <string.h>

int eprefixo (char s1[],char n[]){
  int i,j=0;
  for(i=0;s1[i]!='\0';i++){
    if ((n[j]!=s1[i]) && (n[j]!='\0')){
      return 0;
      break;
    }
    j++;
  }
  return 1;
}

int sufPref (char s1[], char s2[]) {
  int i=0,j=0,n;
  if (eprefixo(s1+i,s2+j)==0){
    i++;
  }
  n=strlen(s1+i)-1;
  return n;
}

int main () {
  char s2[]="totalidade";
  char s1[]="batota";
  int r;
  r=sufPref (s1,s2);
  printf("%d",r);
  return 0;
}
  
