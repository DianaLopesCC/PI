#include <stdio.h>
#include <string.h>

int limpaEspacos (char t[]){
  int i=0,j,n=0,m=0;
  for (j=1;t[j]!='\0';j++){
    if (t[j]==' ' && t[j+1]==' '){
      m++;
    }
    n++;
  }
  n=n-m;
  return n;
}

int main () {
  char t[]="bom dia  de sol";
  int r;
  r=limpaEspacos(t);
  printf ("%d \n",r);
  return r;
}
 
