#include <stdio.h>

int comuns (int a[], int na, int b[], int nb){
  int i,j,r=0;
  for(i=0;i<na;i++){
    for (j=0;j<nb;j++){
      if (a[i]==b[j]){
        r++;
      }
    }
  }
  return r;
}

int main (){
  int a[]={1,2,3,4,5};
  int na=5;
  int b[]={2,11,6,7,8,9,10};
  int nb=7;
  int r;
  r=comuns(a,na,b,nb);
  printf ("%d",r);
  return 0;
}
