#include <stdio.h>
#include <string.h>

int maiorSufixo (char s1 [], char s2 []){
  int i,j,n=0;
     for (i=strlen(s1), j=strlen(s2) ;i!=0 && j!=0;i--, j--){
       if (s1[i] == s2[j]){
	 n++;
       }else{
	 break;
       }
     }
     return n;
}

int main () {
  char s1[]="dians";
  char s2[]="ans";
  int r;
  r=maiorSufixo(s1,s2);
  printf("%d",r);
  return r;
}
