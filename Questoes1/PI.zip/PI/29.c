# include <stdio.h>

void merge (int r [], int a [], int b [],int na, int nb){
  int i=0;
  int j=0;
  int n=0;
  while ( n < na+nb ){
    if (a[i] < b[j]){
      r[n] =  a[i];
      printf("%d\n", r[n]);
      i++;
      n++;
    }
    if (b[j]< a[i]){
      r[n] = b[j];
      printf("%d\n", r[n]);
      j++;
      n++;
    }
    if (j<nb && i>=na){
      r[n]=b[j];
      printf("%d\n", r[n]);
      j++;
      n++;
    }
    if (i<na && j>=nb){
      r[n]=a[i];
      printf("%d\n", r[n]);
      i++;
      n++;
    }
  }
}




int main () {
  int x;
  int r[]={};
  int a[]= {2,3,6};
  int b[]= {1,4,5,7};
  merge (r,a,b,3,4);
  return x;
}
