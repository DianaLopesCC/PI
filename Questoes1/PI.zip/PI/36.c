#include <stdio.h>

int elimRepOrd (int v[], int n){
  int i=0,j,b,r=0;
  b=v[i];
  for (j=1;j<n;j++){
    if (b!=v[j]) r++;
  }
  i++;
  return r;
}

int main () {
  int v[]={1,1,2,3,4,4,5,7};
  int r;
  r=elimRepOrd(v,8);
  printf ("%d",r);
  return r;
}
