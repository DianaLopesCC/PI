#include <stdio.h>


int retiraNeg (int v[], int N) {
  int r=0,i=0;
  int c[1024];
  for (r=0;r<N;r++){
    if (v[r]>=0){
      c[i]=v[r];
      printf ("%d ",c[i]);
      i++;
    }
  }
  return i;
}


int main (){
  int v[]={1,4,-3,-2,1,-1,0};
  int r;
  r=retiraNeg (v,7);
  printf ("%d \n",r);
  return 0;
}
