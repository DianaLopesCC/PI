#include <stdio.h>

int remRep (char x[]){
	int i;
	int cont=0;
	int tam=0,total=0;
	for (i=0;x[i]!='\0';i++){
		tam++;
	}
	for (i=1;x[i]!='\0';i++){
		if (x[i]==x[i-1]){
			cont++;
		}
	}
	total=tam-cont;
	printf("A palavra fica com %d\n", total);
	return 0;
}

int main (){
	char x[]="aabbabba";
	remRep(x);
}