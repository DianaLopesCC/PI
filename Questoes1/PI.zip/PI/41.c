#include <stdio.h>

int triSup (int N, float m [N] [N]){
  int i,j;
  int r;
  for (i=N;i>0;i--){
    for (j=0;(j!=i && j>i && j<N);j++){
      if (m [i][j]==0){
	r=0;
      }else{
	r=1;
	break;
      }
    }
  }
  printf ("%d",r);
  return r;
}

int main (){
  float m [4] [4]={{1,2,3},{1,2,0},{3,0,0}};
  triSup(4,m);
  return 0;
}
