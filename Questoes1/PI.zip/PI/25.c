#include <stdio.h>
#include <string.h>

int palindorome (char s[]) {
  int i;
  int n = strlen (s);
  int r=0;
  for (i=0 ; i <= (n-1)/2; i++){
    if (s[i]!=s[n-1-i]){
      r=1;
      break;
    }
  }
  return r;
}

int main () {
  int total;
  char s[]= "andppna";
  total = palindorome (s);
  printf ("%d\n", total);
}
