# include <stdio.h>

int menosFreq (int v [], int N) {
  int i=0;
  int freq = 1;
  int max = 1;
  int in = 0;
  for (int i = 1; i < N; ++i){
    if (v [i] == v [i-1]){
      freq ++;
      if (max < freq){ 
	max = freq;
	in = v [i];
      }
    }
  }
  return v [i];
}

int main () {
  int x;
  int v [] = {1,2,2,3,3,5,5,5} ;
  x = menosFreq ( v, 8);
  printf("O menos frequente é %d\n", x );
  return 0;
}
  
