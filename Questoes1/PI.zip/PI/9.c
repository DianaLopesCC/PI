# include <stdio.h>

char *strcat2 (char s1[], char s2[]) {
  int i,x;
  for (i = 0; s1[i]!='\0'; i++);
  for (x = 0; s2[x]!='\0'; x++) {
    s1[i+x]=s2[x];
  }
  s1[i+x]='\0';
  return s1;
}

int main () {
  char s1[]="diana";
  char s2[]="abreu";
    printf("%s \n", strcat2(s1,s2));
  return 0;
}
