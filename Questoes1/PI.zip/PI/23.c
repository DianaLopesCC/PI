# include <stdio.h>
# include <string.h>

int contaVogais (char s[]){
	int i,total=0;
	for (i=0;s[i]!='\0';i++){
		if (s[i]=='a' || s[i]=='e' || s[i]=='i' || s[i]=='o' || s[i]=='u'){
			total++;
		}
	}
	printf("Numero %d\n de vogais", total);
	return total;
}

int main (){
	char s[]="dananinhas";
	contaVogais(s);
}