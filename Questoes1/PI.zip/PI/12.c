# include <stdio.h>
# include <string.h>
  
char *strstr2 (char s1[], char s2[]){
  int i,j=0;
  for (i=0;s1[i]!='\0';i++){
    if ((s2[j]==s1[i]) && (s2[j]!='\0')){
      j++;
      return &(s1[i]);
    }
  }
  return NULL;
}


int main (){
  char s1[]="maria";
  char s2[]="mariana";
  printf("%s \n",strstr2(s1,s2));
  return 0;
}
	
	 
