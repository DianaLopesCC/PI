#include <stdio.h>

void sumDiag ( int N, int m [N][N]){
  int i,j,a;
  int s=0;
  int r[N][N];
  for (i=0;i<N;i++){
    for (j=0;j<N;j++){
      if (i==j){
	for (a=i+1;a<N;a++){
	  s=s+m[i][a];
	}
	for (a=i-1;a>=0;a--){
	  s=s+m[i][a];
	}
	r[i][j]=s;
	s=0;
      }
      else{
	r[i][j]=m[i][j];
      }
      s=0;
    }
  }
  for (i=0;i<N;i++){
    for (j=0;j<N;j++){
      printf("%d  ",r[i][j]);
    }
  }
}

int main () {
  int m [4] [4] ={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
  sumDiag (4,m);
  return 0;
}
      
