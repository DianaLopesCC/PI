# include <stdio.h>

int iguaisConsecutivos (char s []) {
  int i;
  int total=1;
  int maior=1;
  int res=0;
  for (i = 0; s[i] != '\0'; ++i) {
    if (s [i] == s [i+1]) {
      total++;
    }else if (s[i]!=s[i+1]){
      total=1;
    }
    if (total > maior) {
      maior = total;
      res = total;
    }     
  }
  return res;
}

int main () {
  int x;
  char s[]= "aaaabcccaac";
  x = iguaisConsecutivos (s);
  printf ("O comprimento maior é %d\n ", x);
}
