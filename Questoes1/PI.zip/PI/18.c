# include <stdio.h>

int difConsecutivos (char s []) {
  int i;
  int total = 1;
  for (i = 0; s[i] != '\0'; ++i) {
      if (s[i] == s[i+1]){
	total = 1;
      }
      else if (s[i] != s[i+1]){
	total++;
      }
    }
  return total;
}

int main () {
  char s[] = "aabcccaac";
  int total;
  total= difConsecutivos (s);
  printf("O comprimento e a palavra sao: %d\n", total);
  return 0;
}
