# include <stdio.h>

void transposta (int N, float m [N][N]){
  int i,j;
  int c[N][N];
  for (i=0;i<N;i++){
    for (j=0;j<N;j++){
      c[j][i]=m[i][j];
      }
    }
  for (j=0;j<N;j++){
    for (i=0;i<N;i++){
      if (i==(N-1)){
	printf("%d \n",c[j][i]);
      }else{
	printf("%d ",c[j][i]);  
      }
    }
  }
}

int main (){
  float m [4][4]={{1,2,3,4},{2,3,4,1},{3,4,2,1},{4,1,2,3}};
  transposta(4,m);
  return 0;
}
