# include <stdio.h>

int maisFreq (int v[], int N){
  int i=0;
  int fre=1;
  int max=1;
  int n=0;
  for (i=1;i<N;i++) {
    if (v[i]==v[i-1]){
      fre++;
      if (max<fre){
	max=fre;
	n=i;
	fre=1;
      }
    }
  }
  return v[n];
}

int main () {
  int x;
  int v[]={1,2,2,3,3,3,4,4,5};
  x=maisFreq(v,9);
  printf("%d",x);
  return x;
}
