# include <stdio.h>

int strcmp1 (char s1[],char s2[]){
  int i,n=0;
  for (i=0;(s1[i]!='\0' || s2[i]!='\0') ;i++){
    if (s1[i]==s2[i]) n=0;
    else if (s1[i]=='\0' && s2[i]!='\0') n--;
    else n++;
  }
  printf("a falavra resulta : %d",n);
  return n;
}

int main (){
  char s1[]="Diana";
  char s2[]="por";
  strcmp1(s1,s2);
  return 0;
}  
