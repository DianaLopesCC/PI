# include <stdio.h>

void addTo (int N , int M , int a [N][M], int b[N][M]){
  int i,j;
  int c [N][M];
  for(i=0;i<N;i++){
    for(j=0;j<M;j++){
      c[i][j]=a[i][j]+b[i][j];
    }
  }
  for(i=0;i<N;i++){
    for(j=0;j<M;j++){
      if (j==(M-1)){
	 printf("%d \n",c[i][j]);
      }else{
	 printf("%d ",c[i][j]);
      }
    }
  }
}

int main (){
  int a [4][3]={{1,0,0},{2,1,0},{3,2,1},{0,1,2}};
  int b[4][3]={{1,0,1},{0,0,1},{0,1,2},{3,2,1}};
  addTo(4,3,a,b);
  return 0;
}
